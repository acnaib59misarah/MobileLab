package com.example.ilazar.mykeep.util;

public interface OnSuccessListener<E> {
    void onSuccess(E e);
}
