package com.example.ilazar.mykeep.util;

public interface OnErrorListener {
    void onError(Exception e);
}
